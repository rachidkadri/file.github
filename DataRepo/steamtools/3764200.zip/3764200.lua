-- ============================================
--  Credits: K3rnelPan1c (KernelOS / !K3rnalyze)
--  Discord: https://discord.gg/k3rnalyze
--  Website: https://kernelos.org/games
-- ============================================

addappid(3764200)
addappid(3764201,0,"bdf443ffde6449192b9863c0fa5e3cda31fdaa5e4d33e5bcded62dc2085b7cb8")
